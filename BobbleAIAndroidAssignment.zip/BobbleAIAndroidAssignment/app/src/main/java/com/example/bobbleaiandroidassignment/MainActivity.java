package com.example.bobbleaiandroidassignment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private EditText editText;
    private Button enterButton;
    private List<MessageModel> messageModelList;
    private ArrayList<String> msgList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.enter_message);
        enterButton = findViewById(R.id.enter_button);
        recyclerView = findViewById(R.id.recycler_view_main);
        recyclerView.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(MainActivity.this);
        linearLayoutManager.setStackFromEnd(true);
        linearLayoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);
        messageModelList = new ArrayList<>();
        msgList = new ArrayList<>();
//        messageModelList.add(new MessageModel("bye"));
//        messageModelList.add(new MessageModel("Hello"));
//        messageModelList.add(new MessageModel("Hello"));
//        messageModelList.add(new MessageModel("Hello"));
//        messageModelList.add(new MessageModel("Hello"));
//        messageModelList.add(new MessageModel("Hello"));
//        messageModelList.add(new MessageModel("Hello"));
//        messageModelList.add(new MessageModel("Hello"));
//
//        MessageAdapter messageAdapter = new MessageAdapter(messageModelList);
//        recyclerView.setAdapter(messageAdapter);
//        messageAdapter.notifyDataSetChanged();
        if(msgList.size()!=0){
            for(String msg: msgList){
                messageModelList.add(new MessageModel(msg));
            }
        }


        enterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String msg = editText.getText().toString();
                if(!msg.equals("")) {
                    messageModelList.add(new MessageModel(msg));
                    MessageAdapter messageAdapter = new MessageAdapter(messageModelList);
                    recyclerView.setAdapter(messageAdapter);
                    messageAdapter.notifyDataSetChanged();
                    InputMethodManager imm = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
                    imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
                    editText.setText("");
                }
                else {
                    Toast.makeText(getApplicationContext(), "Enter a valid message first!" , Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        // Save UI state changes to the savedInstanceState.
        // This bundle will be passed to onCreate if the process is
        // killed and restarted.
        for(int i =0; i< messageModelList.size();i++){
            msgList.add(messageModelList.get(i).getMsg());
        }
        savedInstanceState.putStringArrayList("Message", msgList);
    }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        // Restore UI state from the savedInstanceState.
        // This bundle has also been passed to onCreate.
        for(int i = 0; i<savedInstanceState.getStringArrayList("Message").size();i++){
            msgList.add(savedInstanceState.getStringArrayList("Message").get(i));
        }

    }
}